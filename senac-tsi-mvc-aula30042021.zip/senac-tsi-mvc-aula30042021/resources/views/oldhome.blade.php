@extends('layouts.index')
@section('title', 'TESTE')
@section('sidebar')

@section('content')
  @section('h1', 'Bem-Vindo')
@endsection

@section('footer')
  
